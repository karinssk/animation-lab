import { Space_Grotesk } from "next/font/google";
import { RestaurantSearchPage } from "./components/RestaurantSearchPage";
import "./restaurant-search.css";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata = {
  title: "Restaurant Search",
  description: "Search and discover restaurants on an interactive map",
};

export default function Page() {
  const apiKey = process.env.GOOGLE_PLACE_API_KEY ?? "";

  return (
    <div className={spaceGrotesk.className}>
      <div className="rs-phone-frame">
        <RestaurantSearchPage apiKey={apiKey} />
      </div>
    </div>
  );
}
